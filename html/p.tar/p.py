#!/usr/bin/python2
import os
os.system('setenforce 0')
os.system('iptables -F')
os.system('touch /etc/yum.repos.d/client.repo')
p=open('/etc/yum.repos.d/client.repo','w')
p.write('[client]\n')
p.write('baseurl=ftp://192.168.43.163/pub/yum/Packages/\n')
p.write('gpgcheck=0\n')
p.close()
os.system('yum install openssh-clients -y >/dev/null 2>/dev/null')
os.system('yum install sshpass -y >/dev/null 2>/dev/null')
os.system('sshpass -p redhat ssh  -o  StrictHostKeyChecking=no  -X -l root 192.168.43.163  firefox')
