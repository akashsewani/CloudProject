#!/usr/bin/python2
import commands
commands.getstatusoutput('setenforce 0')
commands.getstatusoutput('iptables -F')
commands.getstatusoutput('sudo yum install nfs-utils -y >/dev/null 2>/dev/null')
commands.getstatusoutput("sudo mkdir /media/bisma")
commands.getstatusoutput("sudo mount 192.168.43.163:/home/bisma/directory /media/bisma")
