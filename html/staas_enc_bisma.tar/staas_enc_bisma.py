#!/usr/bin/python2
import commands
commands.getstatusoutput('setenforce 0')
commands.getstatusoutput('iptables -F')
commands.getstatusoutput('touch /etc/yum.repos.d/client.repo')
p=open('/etc/yum.repos.d/client.repo','w')
p.write('[client]\n')
p.write('baseurl=ftp://192.168.43.163/pub/yum/Packages/\n')
p.write('gpgcheck=0\n')
p.close()
commands.getstatusoutput('sudo yum install fuse-sshfs -y >/dev/null 2>/dev/null')
commands.getstatusoutput("sudo mkdir /media/bisma_enc")
commands.getstatusoutput("echo redhat | sudo sshfs 192.168.43.163:/home/bisma/directory1 /media/bisma_enc --stdin")
